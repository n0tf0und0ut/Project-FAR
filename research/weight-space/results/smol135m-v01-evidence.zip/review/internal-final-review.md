# Bounded internal review of weight-space pilot

Status: Bounded internal source and saved-evidence review COMPLETE. No unresolved reproducible actionable finding identified on the reviewed frozen source.

Reviewed commit: `bb48be7df44adf9d30f018f3528bbd9db49555e1`.
Protected-main/merge-base: `a3f5825ee74af723d660a55e6708ef96e305b156`.
Review date: 2026-11-03. Candidate PR: #613.

## Exposure and independence boundary

Reviewer is a focused agent in the same coordinator thread with shared filesystem and inherited task context. It inspected and challenged pre-freeze source; the coordinator supplied fixes. It did not write the implementation, frozen protocol, task corpus or model evidence. This is internal substantive code inspection with prior shared exposure, not I3 external independence, a new blind oracle, independently controlled model reproduction, scientific acceptance, or protected merge authority. No model inference was run by this reviewer. Raw-evidence replay below is recomputation of saved measurements only.

## Scope and invariants inspected

Inspected complete frozen diff, all four tools, both test modules, protocol, checkpoint manifest, authored task contracts, optional-runtime requirements and documentation. Reviewed parameter selection, trusted-policy separation, source freeze, actual checkpoint-byte hashing, tokenizer/raw output correspondence, grading, complete schedule/failure accounting, random/half/sham controls, numerical rounding, restoration, statistical aggregation and adoption nonpromotion. Confirmed no production imports or package export changes via repository search. Existing core theory and production reasoning remain untouched.

The live model is a single pinned SmolLM2-135M checkpoint, promoted in memory from BF16 serialized values to float32. Proposed selected-column ablation and half ablation address 576 values in last-layer MLP down_proj column1498; the norm-matched control is column778, with norm ratio0.9832406231502356. Independently reconstructed typed edit audits from the exact safetensors and preserved selection arrays: sham0 changed values; ablate576 with tensor relativeL2 0.02103370548654118; half576 with0.01051685274327059; random576 with0.02068119368974527. No semantic circuit identity is inferred from this influence heuristic.

Complete base inventory reconstruction reads every pinned tensor, casts to the recorded float32 load dtype and matches the live named-parameter receipt, omitting only a verified equal tied lm_head duplicate if present. The target tensor is separately matched to the checkpoint before edit reconstruction. Per-slot inventory commitments allow exactly the registered target change; identity sham must match baseline token output at the same prompt/seed. Final restore commitment is checked independently.

## Root-cause ledger

All initial findings applied to uncommitted pre-execution construction source; there were no model observations at that point. Final fix commit is the reviewed public freeze above. Initial synthetic attack artifacts are explicitly infrastructure fixtures, never model-performance evidence.

| ID | Violated invariant and reproducer | Final disposition and verification |
|---|---|---|
| WSP-R1 | Grading trusted separately supplied text without binding it to actual input/output token IDs. Synthetic archive using EOS-only output_ids[2] and fabricated correct text originally received54/54 in every arm. | Fixed: pinned tokenizer re-tokenizes request and decodes output IDs; token limit is recomputed. `test_actual_token_ids_must_decode_to_graded_text` exercises all three mismatches. |
| WSP-R2 | Source freeze used git diff, which ignores untracked source, and replay did not verify source_commit. | Fixed: every source receipt path must exist and match HEAD bytes before inference; replay requires a40-hex commit and matches every receipt byte to that commit and current replay checkout. Untracked-source test passes; synthetic nonexistent commit independently rejected. |
| WSP-R3 | Registered development-loop testability threshold was not applied to the report. | Fixed: all six development raw outputs are tokenizer/hash/grade checked and explicit WSP_HLOOP status is returned. The observed development proxy count is zero; the report must label the loop hypothesis NOT_TESTABLE. |
| WSP-R4 | Replay accepted self-reported proposal/audit dictionaries and incomplete baseline inventory. The initial malicious fixture supplied no actual proposal or weights. | Fixed: pinned original target, preserved development activation arrays, deterministic selection/random control, protocol-owned policy and complete apply_edit audit are reconstructed. Complete checkpoint inventory is independently rebuilt and compared. |
| WSP-R5 | Early-phase failures could escape without a durable attempt/failure receipt. | Fixed: attempt lifecycle writes immutable start/error receipts around model loading/development/selection/scored phases; scored failures also retain their slot identity. `test_failure_in_early_phase_has_durable_receipt` passes. Error receipt does not separately enumerate an execution-stage label; no such stronger property is claimed. |

Reproducer scripts retained outside repository at `work-records/review_reproduce_false_credit.py` and `work-records/review_reproduce_source_commit.py`. These deliberately fabricated archives test controls and are excluded from every live-model count.

## Adjacent experiment integration

PR #611 reviewed at `764e7ac6572e39bcb24fc7a373040780193cc514`. Its FAR-WSP-001 protocol is DESIGN ONLY and NOT REGISTERED, with five specified arms and a serialized-sham requirement. Its generic auditor consumes supplied grades and checkpoint copies; it does not run models or independently reconstruct grading. PR #613 supplies an actual separately frozen eight-arm output-contract pilot with a numerical identity sham and different task scope. It is complementary research, not execution or completion of #611 H1/H2/H3; its results cannot be silently converted into that five-arm contract or pooled with it. No runtime or file-path conflict is introduced. PR #601 remains a distinct activation-fidelity experiment; #605 is a completed negative one-shot repair study; #610 is a separate bounded tool-agent screen.

## Verification completed before final replay

- Exact working source HEAD matched reviewed public freeze; no source changes made by reviewer.
- `python -m unittest tests.test_weight_space_edits tests.test_weight_space_pilot -v` in pinned weight-env:32 tests passed.
- Frozen whole-diff whitespace check passed.
- Actual selected original tensor and four sparse diffs independently reconstructed without neural inference.
- Authored task labels independently inspected: exact output formats, tool action schema, non-entailment cases and regression arithmetic/extraction contracts are coherent. Author-curated labels remain narrow and nonexternal.
- No observed remaining reproducible code defect invalidates the current frozen observation design. That is a bounded assessment, not proof of universal correctness.

## Material limits

One-shot authored output contracts do not establish multistep tool execution or general agent reliability. The proposer is a fixed model-authored heuristic, not an independently validated mechanistic explanation. No external blind dataset, frontier model evaluation, cross-model transfer, customer-value study, full model-generation reproduction, or production endorsement is supplied. The random control matches column norm within10%, not learned semantic importance. Bootstrap intervals describe task resampling within this authored cohort; they do not justify population significance. Generation token/CPU/wall costs exclude setup and edit selection. A cryptographic trace checks supplied bytes and computation consistency; a malicious host could fabricate an internally consistent run, so independent execution remains required.

## Final raw-evidence replay

Completed independent replay of all 432 scored rows and six development receipts using the exact pinned tokenizer/checkpoint and frozen source. Report matched the original in-process analysis exactly. Independently recounted every correctness label from raw text and task contracts with zero disagreements. All12 targeted malicious-copy mutations were rejected: nonexistent/unrelated source commit, incomplete full inventory, token/text mismatch, false grade, policy override, missing/extra slot, wrong original tensor, altered selection activations, substituted seed and baseline/sham divergence. Original evidence was never modified.

Raw artifact files: 448; canonical raw-file manifest SHA-256 `b10f4f8203f317e2926f329aef9f4dc1b0fe6489f5992d5af0332c6e227fcdad`. Independent analysis bytes SHA-256 `ad137504d920e6d466be8691009e55665bfc8bf1cf721049da1ea9de43f4a20b`. Full exact receipt: `work-records/final-weight-review-receipt.json`. These are saved-evidence checks, not a second inference run or external scientific replication.

| Arm | Correct/all | Heldout correct/all | Regression correct/all | Tasks correct in every repeat |
|---|---:|---:|---:|---:|
| baseline | 0/54 | 0/36 | 0/18 | 0/18 |
| sham | 0/54 | 0/36 | 0/18 | 0/18 |
| ablate | 1/54 | 1/36 | 0/18 | 0/18 |
| half_ablate | 0/54 | 0/36 | 0/18 | 0/18 |
| random_ablate | 0/54 | 0/36 | 0/18 | 0/18 |
| prompt | 1/54 | 1/36 | 0/18 | 0/18 |
| decoding | 0/54 | 0/36 | 0/18 | 0/18 |
| budget | 0/54 | 0/36 | 0/18 | 0/18 |

Registered loop hypothesis: **NOT_TESTABLE; fewer than two development repetition-proxy failures**. Production eligibility remains **false**. Protected CI, exact-head review convergence and merge authorization remain separate gates.


## Post-registration semantic sensitivity

Frozen primary grades and source bytes were preserved. A separately labeled sensitivity admitted case-only yes/no answers and exactly schema-conformant calculator JSON containing the same two multiplicative operands (whitespace, parentheses or operand-order variation). Prose, markdown, altered schemas, computed replacement constants and other format violations remain failures. This is a conservative post-outcome interpretation check, not a new run or primary result.

Changed primary failures: 3 total; 3 label-case equivalents and 0 tool-expression equivalents. slot-0090.json budget 'No'; slot-0091.json baseline 'No'; slot-0095.json sham 'No'.

| Arm | Primary correct/all | Sensitivity correct/all |
|---|---:|---:|
| baseline | 0/54 | 1/54 |
| sham | 0/54 | 1/54 |
| ablate | 1/54 | 1/54 |
| half_ablate | 0/54 | 0/54 |
| random_ablate | 0/54 | 0/54 |
| prompt | 1/54 | 1/54 |
| decoding | 0/54 | 0/54 |
| budget | 0/54 | 1/54 |

The sensitivity qualifies strict-output score claims; it does not rescue H1, show weight-edit advantage or provide a general task-correctness benchmark. Exact changed rows and per-split counts are retained in `work-records/weight-v01-semantic-sensitivity.json`.

## Regression floor and final scientific disposition

All primary regression arms score0/18. The mechanical `regression_tolerance_met: true` flag reflects a zero difference at the score floor; it supplies no evidence of preserved useful capability or absence of regressions. A useful regression safety claim requires a baseline-positive independent task battery. The selected ablation scores1/36 heldout, tying the prompt-only arm1/36 and failing the registered5-percentage-point benefit criterion against it. The half ablation scores0/36. No weight-specific advantage, causal loop repair or production consideration is warranted. Preserve the candidate as a completed negative bounded pilot; further mechanism study needs an empirically reproducible failure and stronger independent tasks.
