FAR bounded tool-agent evaluation v0.3 — evidence bundle

Research. The 7B configuration passed 72/72 authored simulated task executions,
24/24 tasks on all three attempts, with no unsafe writes or missing evidence.
General agent reliability and FAR causal improvement remain NOT ESTABLISHED.

Contents:
- original-artifacts/: all 14 original GitHub Actions ZIPs, unchanged.
- metadata/: primary API metadata, exact frozen-source identity, raw-file hashes,
  and internal provenance audit. SHA256SUMS covers every member except itself.
- Complete original artifact 13224187919.zip contains all 75 raw records
  (72 scored, three excluded preflight) and both hosted reports.

Restore and replay (Python 3.12; Git required; no model inference/download):
1. Extract this bundle and verify SHA256SUMS.
2. Extract original-artifacts/13224187919.zip to a directory named raw.
3. In a Project-FAR checkout, fetch and detach at source commit
   6c382c798df0a95824b79e76263318865ee24c68.
4. From that checkout run:
   python -m tools.tool_agent_reliability analyze --phase preflight --inputs ABSOLUTE_BUNDLE_PATH/raw/preflight --out /tmp/replayed-preflight.json
   python -m tools.tool_agent_reliability analyze --phase scored --inputs ABSOLUTE_BUNDLE_PATH/raw/scored --out /tmp/replayed-scored.json
5. Compare the resulting JSON with raw/preflight-report.json and
   raw/scored-report.json. The scored report SHA-256 is
   6bcb51d5da359f17f8c33f88c1f2afa28197648c12a9dcf73bc8e94a7a34c471.

The immutable source contains the exact protocol and analyzer; no repository
source code or model weights are duplicated here. This replays retained tool
transitions and grades. It does not regenerate the model or count as external
independent replication. Different seeds at temperature zero mostly produced
identical trajectories; these are not 72 independent population samples.
Earlier 1.5B stages and their failed gates are retained separately in the
repository. Never pool preflights or predecessor studies into this result.
