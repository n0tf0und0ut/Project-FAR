#!/usr/bin/env python3
"""Software-only replay of exposed existing controls; no scientific promotion."""
import argparse, hashlib, importlib.metadata, importlib.util, json, platform
from pathlib import Path
import socket, sys, time, uuid
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/e1c41a89d76e/Project-FAR')
HERE = Path(__file__).resolve().parent
FILES = ['commercial/far-investigation-audit/evaluation/internal-001/cases-v1.json',
         'commercial/far-investigation-audit/engine.py',
         'tools/run_internal_investigation_evaluation.py']

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n')
def imports():
    sys.path.insert(0, str(ROOT/'commercial/far-investigation-audit'))
    import engine
    spec=importlib.util.spec_from_file_location('existing_eval', ROOT/FILES[-1])
    evaluator=importlib.util.module_from_spec(spec);spec.loader.exec_module(evaluator)
    return engine,evaluator
def freeze():
    path=HERE/'local-sdk-protocol.json'
    if path.exists(): raise ValueError('immutable existing protocol')
    record={'scope':'EXPOSED_EXISTING_FIXTURE_SOFTWARE_INTEROPERABILITY_ONLY',
      'scientific_independence':False,'new_confirmatory_experiment':False,
      'timestamp':datetime.now(timezone.utc).isoformat(),
      'main_commit':'c7456b469f9dfe88b92d0fc7a211e5c9ed64de61',
      'inputs':{p:sha(ROOT/p) for p in FILES},'script_sha256':sha(Path(__file__)),
      'versions':{n:importlib.metadata.version(n) for n in ['sympy','langsmith','arize-phoenix-evals']},
      'python':platform.python_version(),
      'outcomes':'Retain all 46 exposed formula cases, FAR abstentions, both baseline statuses, exact per-case SDK scoring; no timed agent or causal-diagnosis superiority claim.',
      'network':'Socket connect blocked; upload_results=False. Zero model calls intended.',
      'methods':'FAR and independent SymPy each receive identical formulas without reference labels. LangSmith orchestrates both; Phoenix scores the same per-case statuses with explicit abstention and correctness metrics. No hosted dashboards or LLM judges run.',
      'nonclaims':['general agent reliability','causal identification','repair effectiveness','customer value','LangSmith/Phoenix platform superiority','independent scientific replication']}
    write(path,record); return record
def run():
    protocol=json.loads((HERE/'local-sdk-protocol.json').read_text())
    assert protocol['inputs']=={p:sha(ROOT/p) for p in FILES}
    assert protocol['script_sha256']==sha(Path(__file__))
    assert protocol['versions']=={n:importlib.metadata.version(n) for n in protocol['versions']}
    engine,ev=imports()
    corpus=ev.validate_cases(ev.read(ROOT/FILES[0])); cases=corpus['formal_comparison']
    from langsmith import Client, evaluate
    from langsmith.schemas import Example
    import pandas as pd
    from phoenix.evals import create_evaluator,evaluate_dataframe
    attempts=[]
    def blocked(*args,**kwargs):
        attempts.append(str(args[1:])); raise RuntimeError('network disabled in local SDK software probe')
    socket.socket.connect=blocked;socket.create_connection=blocked
    client=Client(api_url='http://127.0.0.1:1',api_key='offline-software-probe',auto_batch_tracing=False)
    def target_far(inputs):
        return {'status':engine.entailment(inputs['premises'],inputs['conclusion'])['status']}
    def target_sympy(inputs):
        return {'status':ev.sym_status(inputs['premises'],inputs['conclusion'])}
    def grade(outputs,reference_outputs):
        return [{'key':'status_match','score':int(outputs['status']==reference_outputs['status'])},
                {'key':'abstention','score':int(outputs['status'].startswith('NOT_CHECKED'))}]
    examples=[Example(id=uuid.uuid5(uuid.NAMESPACE_URL,'far-probe:'+r['case_id']),
        dataset_id=uuid.uuid5(uuid.NAMESPACE_URL,'far-probe:dataset'),
        inputs={'case_id':r['case_id'],'premises':r['premises'],'conclusion':r['conclusion']},
        outputs={'status':r['reference_status']}) for r in cases]
    records=[]
    for name,target in [('far',target_far),('sympy',target_sympy)]:
        tick=time.perf_counter()
        rows=list(evaluate(target,data=examples,evaluators=[grade],upload_results=False,
            client=client,max_concurrency=0,blocking=True,experiment_prefix='local-exposed-software-probe-'+name))
        elapsed=time.perf_counter()-tick
        for row in rows:
            reference=row['example'].outputs['status']; outputs=row['run'].outputs
            records.append({'arm':name,'case_id':row['example'].inputs['case_id'],
                'status':outputs['status'],'reference':reference,
                'sdk_scores':{s.key:s.score for s in row['evaluation_results']['results']},
                'error':row['run'].error})
        write(HERE/('langsmith-'+name+'.json'),{'elapsed_seconds':elapsed,'rows':records[-len(rows):]})
    @create_evaluator(name='status_match',source='code')
    def status_match(status,reference): return int(status==reference)
    @create_evaluator(name='abstention',source='code')
    def abstention(status): return int(status.startswith('NOT_CHECKED'))
    frame=evaluate_dataframe(pd.DataFrame(records),[status_match,abstention],hide_tqdm_bar=True,
        exit_on_error=True,max_retries=0)
    frame.to_json(HERE/'phoenix-scores.json',orient='records',indent=2)
    summary={'protocol_sha256':sha(HERE/'local-sdk-protocol.json'),
        'cases':len(cases),'target_executions':len(records),'network_connect_attempts':attempts,
        'scope':protocol['scope'],'model_calls':0,'external_model_api_charge':0,
        'total_compute_human_or_billing_cost_measured':False,
        'arms':{name:{'n':len([r for r in records if r['arm']==name]),
          'reference_match':sum(r['status']==r['reference'] for r in records if r['arm']==name),
          'abstentions':sum(r['status'].startswith('NOT_CHECKED') for r in records if r['arm']==name),
          'target_errors':sum(bool(r['error']) for r in records if r['arm']==name)} for name in ['far','sympy']},
        'phoenix_rows':len(frame),'nonclaims':protocol['nonclaims']}
    assert len(records)==92 and len(frame)==92
    assert all(r['sdk_scores']['status_match']==int(r['status']==r['reference']) for r in records)
    assert len({(r['arm'],r['case_id']) for r in records})==92
    assert not attempts
    write(HERE/'local-sdk-results.json',summary); return summary
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['freeze','run']);a=p.parse_args()
    print(json.dumps(freeze() if a.action=='freeze' else run(),indent=2))
