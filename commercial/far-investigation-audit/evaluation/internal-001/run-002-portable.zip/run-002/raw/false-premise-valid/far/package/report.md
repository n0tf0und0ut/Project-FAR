# FAR Investigation: false-premise-valid

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-26T12:00:00Z`
- Input SHA-256: `f1101c99700dfe41e6fa7e08c3ef2a927adbbe1194124b543d6a7f0059d2a37a`
- Report SHA-256: `2c27dbf9553d9ce7735b47ecfe50c7dc032eeba0bd88f19e9b6ca9fd2ce46d0e`
- Source snapshots: 1; claim candidates: 3; candidate readings: 0
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:15`

Source quotation:

```text
The lamp is on.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `16:55`

Source quotation:

```text
If the lamp is on then the room is lit.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c3

Source: `primary`; exact span: `56:72`

Source quotation:

```text
The room is lit.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

No explicit argument was identified. No inference verdict was issued.

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=4a96d418521739b0c38cb801869a33056c7da4ebdb7a1e89c591a2e47ce90634; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
