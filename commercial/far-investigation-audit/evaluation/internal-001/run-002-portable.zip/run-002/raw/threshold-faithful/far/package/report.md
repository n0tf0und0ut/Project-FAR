# FAR Investigation: threshold-faithful

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-26T12:00:00Z`
- Input SHA-256: `89f7a431645904d083779d828b014476971419076f085ae9dafa4eba73ce10fe`
- Report SHA-256: `0ce1c4acd1a08a05b7f9eb4adebb22af7fe379ec3393e6935ca1132d7bc12d0a`
- Source snapshots: 1; claim candidates: 2; candidate readings: 0
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:35`

Source quotation:

```text
At least ten audits were completed.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `36:72`

Source quotation:

```text
More than ten audits were completed.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

No explicit argument was identified. No inference verdict was issued.

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=4ff4ba03fc1861dfd2b2d792bd8ff2bcf08d4ab11ba441294b0960775e96e92f; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
