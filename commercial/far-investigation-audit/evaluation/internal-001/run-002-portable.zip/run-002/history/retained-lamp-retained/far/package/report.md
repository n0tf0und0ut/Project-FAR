# FAR Investigation: retained-lamp

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-26T12:00:00Z`
- Input SHA-256: `e2fcce3c4e14a811613f05d3a7ede2cff1e08e588fb620909263a87e426f8d7c`
- Report SHA-256: `a0ad680e905cb426e570532ed2442d2da3206466b8a9e8baa6533a8a144ca74a`
- Source snapshots: 2; claim candidates: 1; candidate readings: 0
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:31`

Source quotation:

```text
The device was inspected today.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

No explicit argument was identified. No inference verdict was issued.

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=7e9d2370f0900881c1be2a7d889f70c5929e431ad83fbd68f5b71df26dd449b8; authenticity=unverified
- ev1: ev1; method=text\_provided\_v1; raw SHA-256=24c83a1edcbe329ed82f0086470ca5d8cca08fbf6d6d40f217e402a32bc64adf; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
