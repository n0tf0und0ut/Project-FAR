# FAR Investigation: retained-audit

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-26T12:00:00Z`
- Input SHA-256: `a4021724fc7bd950dd92f57a7cfb0aa0a4e2bd29e61af590df33a2685fbc4fb8`
- Report SHA-256: `eae51851d0688f55df2972dc9601c32d017782eb4de2037b261d02243ab7f9b4`
- Source snapshots: 1; claim candidates: 1; candidate readings: 0
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:35`

Source quotation:

```text
The quarterly report was published.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

No explicit argument was identified. No inference verdict was issued.

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=a648edc2f7669d29bcc4b294a88be6dd3a0472c82dc1f4fad7826e24a9a8e1b5; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
