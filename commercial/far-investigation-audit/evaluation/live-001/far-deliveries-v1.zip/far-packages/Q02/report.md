# FAR Investigation: live-001-Q02

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T17:10:14.558355Z`
- Input SHA-256: `a208a6447c87d039a486745fe74d7790697e6c4b52414b0f8f0a95ef45f4984a`
- Report SHA-256: `78e7bef76b6f68a9ac50145dcade957e681d6dbb6610a0a1a3618ad0c03c838a`
- Source snapshots: 1; claim candidates: 1; candidate readings: 0
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:131`

Source quotation:

```text
Which original experiment tested whether people who disagree about capital punishment evaluate the same mixed evidence differently?
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

No explicit argument was identified. No inference verdict was issued.

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=d6d9c5884f0e10e6316446551f4aa43172c2adc555a54da5ab361c49c49c00c2; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
