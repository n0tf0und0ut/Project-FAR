# FAR Investigation: live-001-R03

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T17:10:08.299879Z`
- Input SHA-256: `9f0db6f5e0dec07b713c9ecc36725aa26ba7c9098dceb97cb97bd2af9ef599c3`
- Report SHA-256: `01b712dbceab9b6f60d539c5833f5a7ba597a1833abd936f35d36a8eeada9ce2`
- Source snapshots: 1; claim candidates: 3; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:33`

Source quotation:

```text
If it rains, the pavement is wet.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `34:51`

Source quotation:

```text
It does not rain.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c3

Source: `primary`; exact span: `52:86`

Source quotation:

```text
Therefore the pavement is not wet.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### candidate_1

- Premises: c2; conclusion: c3
- Formal result: **NOT_CHECKED_UNFORMALIZED**
- Natural-language fidelity: **unverified**
- Interpretation: heuristic discourse-cue candidate; not a faithful formalization
- Unestablished premises: c2

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=ee65f224b58983b290a2a782e4c68dee1e489e0e0bfa6be071b1f4d317e0fd63; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
