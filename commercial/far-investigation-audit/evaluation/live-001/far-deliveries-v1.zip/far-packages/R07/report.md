# FAR Investigation: live-001-R07

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T17:10:09.573026Z`
- Input SHA-256: `3136e270bee71625584b00b98b4bc90fbc6b23ab1942fc92068c7f9dabf12523`
- Report SHA-256: `66bbf3957d1934110ee7fbe9ce423ea55633074eda66dd397cb31d2d59d5f378`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:65`

Source quotation:

```text
The politician made incompatible statements about the same event.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `66:109`

Source quotation:

```text
Therefore the politician deliberately lied.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### candidate_1

- Premises: c1; conclusion: c2
- Formal result: **NOT_CHECKED_UNFORMALIZED**
- Natural-language fidelity: **unverified**
- Interpretation: heuristic discourse-cue candidate; not a faithful formalization
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=b93f268e7a3f2c135f4232f41448348af1faa9b9e3babec396ec1b68abffdbd6; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
