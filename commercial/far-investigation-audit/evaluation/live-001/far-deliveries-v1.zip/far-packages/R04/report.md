# FAR Investigation: live-001-R04

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T17:10:08.497949Z`
- Input SHA-256: `2e7f6aa5657e7854f38b1dc69350224a42d81cf09c76bb35656c0dbfe771f746`
- Report SHA-256: `3ee1ea314d463b99065dab13a7f0275ca62fe89a59d53e58c91530464e9780b1`
- Source snapshots: 1; claim candidates: 3; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:33`

Source quotation:

```text
If it rains, the pavement is wet.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `34:58`

Source quotation:

```text
The pavement is not wet.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c3

Source: `primary`; exact span: `59:86`

Source quotation:

```text
Therefore it does not rain.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### candidate_1

- Premises: c2; conclusion: c3
- Formal result: **NOT_CHECKED_UNFORMALIZED**
- Natural-language fidelity: **unverified**
- Interpretation: heuristic discourse-cue candidate; not a faithful formalization
- Unestablished premises: c2

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=d052569c7b6a0609dd62f449a80e63260d53c751e9292d80e069405a5c6e0267; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
