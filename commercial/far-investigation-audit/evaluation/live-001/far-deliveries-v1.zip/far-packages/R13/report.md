# FAR Investigation: live-001-R13

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T17:10:12.738645Z`
- Input SHA-256: `d5d0bc98e78db90273817c90303725c82bd90d197058812977fac0b0704f39bb`
- Report SHA-256: `68a756ff5e861f83a17cc2781cfaf1e19a1e83f2bdb262843d1f5961345b90a3`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:74`

Source quotation:

```text
The AI reports 99 percent confidence without evidence or calibration data.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `75:119`

Source quotation:

```text
Therefore its answer is established as true.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### candidate_1

- Premises: c1; conclusion: c2
- Formal result: **NOT_CHECKED_UNFORMALIZED**
- Natural-language fidelity: **unverified**
- Interpretation: heuristic discourse-cue candidate; not a faithful formalization
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=c5af08eb77a6d6b9d983edd67bce8445d24781e118537b404e7a9238ceb68c93; authenticity=unverified

## Argument-scheme critical questions (unadjudicated)

These are hypothesis/checklist triggers, NOT findings that an argument is invalid.

- c1 / NUMERICAL\_DENOMINATOR: Are denominator, reference period, sampling frame and measurement definition specified and source-backed?

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
