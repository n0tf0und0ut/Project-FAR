# FAR Investigation: live-001-Q01

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T17:10:14.107291Z`
- Input SHA-256: `331e7078995f8feea08311e0d5aa6f1e53194e875c7b09c5eb17813f4d8eca8b`
- Report SHA-256: `3040b340c6ea3c2de72563ac12485ff0809c50b02f30d960ffa619cbf7fe2dbb`
- Source snapshots: 1; claim candidates: 1; candidate readings: 0
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:132`

Source quotation:

```text
Which original studies tested whether describing identical risky outcomes as lives saved versus lives lost changes people's choices?
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

No explicit argument was identified. No inference verdict was issued.

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=b767dc75e696e5e3160ff125332d7019d00876e9992e1d7f0c6f710e216026e6; authenticity=unverified

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
