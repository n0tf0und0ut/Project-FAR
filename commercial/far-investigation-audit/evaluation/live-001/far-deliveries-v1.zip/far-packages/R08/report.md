# FAR Investigation: live-001-R08

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T17:10:10.502096Z`
- Input SHA-256: `c81200a6faa40db265b928a510f4c650b2fd0ed8064b268ebb7566f8f967fa48`
- Report SHA-256: `896e951d3ca25a2252a8fd606a69368bcc2c50749c9f2643367d6c8e7a7319e3`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:79`

Source quotation:

```text
The observed rate fell from 15 cases per 100 people to 12 cases per 100 people.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `80:128`

Source quotation:

```text
Therefore the relative reduction was 50 percent.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### candidate_1

- Premises: c1; conclusion: c2
- Formal result: **NOT_CHECKED_UNFORMALIZED**
- Natural-language fidelity: **unverified**
- Interpretation: heuristic discourse-cue candidate; not a faithful formalization
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=1ac32352a94c635fae75b3c27db3d29c828210107787e20ca6ea9a1753d2611b; authenticity=unverified

## Argument-scheme critical questions (unadjudicated)

These are hypothesis/checklist triggers, NOT findings that an argument is invalid.

- c1 / NUMERICAL\_DENOMINATOR: Are denominator, reference period, sampling frame and measurement definition specified and source-backed?
- c2 / NUMERICAL\_DENOMINATOR: Are denominator, reference period, sampling frame and measurement definition specified and source-backed?

## Unknowns and blockers

- Claim extraction is heuristic; skipped claims and implicit premises may exist.
- Source identity, meaning, and factual reliability have not been independently verified.
- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
