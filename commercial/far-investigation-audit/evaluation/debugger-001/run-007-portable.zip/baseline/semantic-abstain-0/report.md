# FAR Investigation: semantic-abstain-0

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T12:00:00Z`
- Input SHA-256: `e2ca9a2e059099812e3573d39eb3fb563bc263df52c855892c98bcc9387145c3`
- Report SHA-256: `cd663451ea8f69afddd34e6a6e93dd6d7b3619e32b39841899cd947eabb4e4d4`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:26`

Source quotation:

```text
Every student read a book.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `27:53`

Source quotation:

```text
Every student read a book.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: c1; conclusion: c2
- Formal result: **ENTAILS_CONDITIONALLY**
- Natural-language fidelity: **unverified**
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=c064af7f94f665f7d870264cabfb54fbd0811d851588c76f0049db50a97de78a; authenticity=unverified

## Argument-scheme critical questions (unadjudicated)

These are hypothesis/checklist triggers, NOT findings that an argument is invalid.

- c1 / UNIVERSAL\_GENERALIZATION: Does the sampled population and operational measure cover the full quantified population and exceptions?
- c2 / UNIVERSAL\_GENERALIZATION: Does the sampled population and operational measure cover the full quantified population and exceptions?

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
