# FAR Investigation: threshold-faithful

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-26T12:00:00Z`
- Input SHA-256: `1c718492c101b0e9cf2b8572e57ab44668d76b22e98362c3b0d776a191da3124`
- Report SHA-256: `f087bf36433cddff32d3a8e44e7f141e2bb76793f796619eed8a2ce98db545cb`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### p1

Source: `primary`; exact span: `0:35`

Source quotation:

```text
At least ten audits were completed.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### p2

Source: `primary`; exact span: `36:72`

Source quotation:

```text
More than ten audits were completed.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: p1; conclusion: p2
- Formal result: **DOES_NOT_ENTAIL**
- Natural-language fidelity: **unverified**
- Interpretation: Developer supplied; semantic fidelity is not established by the tool.
- Formal countermodel: `{"P": true, "Q": false}`
- Unestablished premises: p1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=4ff4ba03fc1861dfd2b2d792bd8ff2bcf08d4ab11ba441294b0960775e96e92f; authenticity=unverified

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
