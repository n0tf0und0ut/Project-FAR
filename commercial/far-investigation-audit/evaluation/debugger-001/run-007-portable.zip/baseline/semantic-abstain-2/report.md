# FAR Investigation: semantic-abstain-2

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T12:00:00Z`
- Input SHA-256: `33c3d138b379ea15c845be81522b676907b8ff78088dd72694f794bf4551a4bf`
- Report SHA-256: `64953887eb078b8f4e85c99f32e122f147b73e6a8fc99393b7498e4a51d1fb1c`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:23`

Source quotation:

```text
Not all birds are blue.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `24:47`

Source quotation:

```text
Not all birds are blue.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: c1; conclusion: c2
- Formal result: **ENTAILS_CONDITIONALLY**
- Natural-language fidelity: **unverified**
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=8c8c94e19c120cbef01096d9d6e2131212a43fb3cacdb1a2615e33d7252f07d5; authenticity=unverified

## Argument-scheme critical questions (unadjudicated)

These are hypothesis/checklist triggers, NOT findings that an argument is invalid.

- c1 / UNIVERSAL\_GENERALIZATION: Does the sampled population and operational measure cover the full quantified population and exceptions?
- c2 / UNIVERSAL\_GENERALIZATION: Does the sampled population and operational measure cover the full quantified population and exceptions?

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
