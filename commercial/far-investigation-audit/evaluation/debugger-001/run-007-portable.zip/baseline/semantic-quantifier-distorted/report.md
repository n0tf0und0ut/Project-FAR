# FAR Investigation: semantic-quantifier-distorted

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T12:00:00Z`
- Input SHA-256: `f3d83add8de283cc4dca8dae037019fd146abef67523b36f20b8236fc694bd4a`
- Report SHA-256: `87a3778db7b22e306ad15d1eb6978cfe6ccaa0a0c55903a3f8e81130f3cb4d6b`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:20`

Source quotation:

```text
Some birds are blue.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `21:40`

Source quotation:

```text
All birds are blue.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: c1; conclusion: c2
- Formal result: **ENTAILS_CONDITIONALLY**
- Natural-language fidelity: **unverified**
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=f60ae5b0c63f83aab01ef27c78d55ec744620ea4495e17a93792d6aeba1a3b66; authenticity=unverified

## Argument-scheme critical questions (unadjudicated)

These are hypothesis/checklist triggers, NOT findings that an argument is invalid.

- c2 / UNIVERSAL\_GENERALIZATION: Does the sampled population and operational measure cover the full quantified population and exceptions?

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
