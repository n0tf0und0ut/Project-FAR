# FAR Investigation: semantic-threshold-distorted

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T12:00:00Z`
- Input SHA-256: `ab945e4939681e54abdfeab8c36fde2c1e71a5b7b825a2372c6e2e4f29a2ecb4`
- Report SHA-256: `337f97977a9ef0642605b145ddbde9dcaa4fd06043a1665d6fef791d45f4907b`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:26`

Source quotation:

```text
At least 3 birds are blue.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `27:53`

Source quotation:

```text
At least 2 birds are blue.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: c1; conclusion: c2
- Formal result: **ENTAILS_CONDITIONALLY**
- Natural-language fidelity: **unverified**
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=5bb9b29360813d94c1cb28229f4a469b19cb9029a0dcc57bf2d69471b97f177b; authenticity=unverified

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
