# FAR Investigation: correlation-causal-jump

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-26T12:00:00Z`
- Input SHA-256: `27f59f00cb2d838118b487294311f823b9e6e3101a1fbafe50b0f3b83b6f6db3`
- Report SHA-256: `2d702ab12db6809c0ca7043325c51c88c3d294c82905c4ce58aa6513e5b5708d`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### p1

Source: `primary`; exact span: `0:36`

Source quotation:

```text
Sales rose after the policy changed.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### p2

Source: `primary`; exact span: `37:68`

Source quotation:

```text
The policy caused the increase.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: p1; conclusion: p2
- Formal result: **DOES_NOT_ENTAIL**
- Natural-language fidelity: **unverified**
- Interpretation: Developer supplied; semantic fidelity is not established by the tool.
- Formal countermodel: `{"P": true, "Q": false}`
- Unestablished premises: p1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=815b1d7f8566609ffb773fba6ae62c8171b88b4498889555802ad664e34b62c2; authenticity=unverified

## Argument-scheme critical questions (unadjudicated)

These are hypothesis/checklist triggers, NOT findings that an argument is invalid.

- p2 / CAUSAL\_IDENTIFICATION: Does independent causal-identification evidence address confounding, directionality and alternatives? Temporal sequence/correlation alone is insufficient.

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation
