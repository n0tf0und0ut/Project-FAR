# FAR Investigation: semantic-temporal-faithful

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T12:00:00Z`
- Input SHA-256: `b4e940b83b8689e5f5b16b16d0249126827d41c2c7d23d0aa2dc40bbcfe958bd`
- Report SHA-256: `14160f8cdd89b87353ba233cda255a9059767ce77d4b87534a25e29761a6507b`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:32`

Source quotation:

```text
Some birds are blue before 2020.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `33:65`

Source quotation:

```text
Some birds are blue before 2020.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: c1; conclusion: c2
- Formal result: **ENTAILS_CONDITIONALLY**
- Natural-language fidelity: **unverified**
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=16577116cc74dbd09c4fd8a8861241313cff2830a58aa3f71777a803fc1ec7d1; authenticity=unverified

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation

## Epistemic debugger

Controlled-language checks; external truth and general semantic fidelity remain unverified.

- c1: SUPPORTED_IN_GRAMMAR
- c2: SUPPORTED_IN_GRAMMAR
- reading: CONDITIONAL_ON_GRAMMAR_AND_PREMISES; ENTAILS_CONDITIONALLY; counterfactual EXACT_MINIMUM_WITHIN_CONTRACT.

Full exact source references, lost-distinction witnesses, assumption edits, dependency graph and limitations: debugger.json.
