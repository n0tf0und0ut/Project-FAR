# FAR Investigation: semantic-abstain-6

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T12:00:00Z`
- Input SHA-256: `1edc7a04e53050876fe106b74cbc2f528620c31f2e8edecf01e4da975162a65d`
- Report SHA-256: `a93e66637604d0b0a33f0aaac448427b7d3d54451eb8179c9102ed5bc6d97716`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:30`

Source quotation:

```text
Some birds are allegedly blue.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `31:61`

Source quotation:

```text
Some birds are allegedly blue.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: c1; conclusion: c2
- Formal result: **ENTAILS_CONDITIONALLY**
- Natural-language fidelity: **unverified**
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=2ac20f7c36f6f9035d9acfc86dfa3bff9cf6f9c880c83439563af45d0ed2a60e; authenticity=unverified

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation

## Epistemic debugger

Controlled-language checks; external truth and general semantic fidelity remain unverified.

- c1: ABSTAIN
- c2: ABSTAIN
- reading: NOT_ACCEPTED; UNKNOWN_SEMANTICS; counterfactual EXACT_MINIMUM_WITHIN_CONTRACT.

Full exact source references, lost-distinction witnesses, assumption edits, dependency graph and limitations: debugger.json.
