# FAR Investigation: exact-citation-irrelevant

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-26T12:00:00Z`
- Input SHA-256: `6980b429a9cc7798b3faa67990f44adc96dd2d97a562035aaa771609d01a07b2`
- Report SHA-256: `ccc44ee3365a441da2ace975b1ffa60b943dbc32909829646b761f939a3bbaf7`
- Source snapshots: 2; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### p1

Source: `primary`; exact span: `0:15`

Source quotation:

```text
The lamp is on.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 1

  - Evidence `e1`: TEMPORAL_NOT_ADMISSIBLE

### p2

Source: `primary`; exact span: `16:32`

Source quotation:

```text
The room is lit.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: p1; conclusion: p2
- Formal result: **DOES_NOT_ENTAIL**
- Natural-language fidelity: **unverified**
- Interpretation: Developer supplied; semantic fidelity is not established by the tool.
- Formal countermodel: `{"P": true, "Q": false}`
- Unestablished premises: p1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=d63029ed7f18d724b883e4e603dbc58f6b62341a89f47d45cc841f1d42599f92; authenticity=unverified
- ev1: ev1; method=text\_provided\_v1; raw SHA-256=d1e6bfb05d3af1c1a6ca198044a01aba35a5ef6ce1623a1855203e1eebc6af0b; authenticity=unverified

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation

## Epistemic debugger

Controlled-language checks; external truth and general semantic fidelity remain unverified.

- p1: SUPPORTED_IN_GRAMMAR
- p2: SUPPORTED_IN_GRAMMAR
- reading: NOT_ACCEPTED; DOES_NOT_ENTAIL; counterfactual NO_REPAIR_WITHIN_CONTRACT.

Full exact source references, lost-distinction witnesses, assumption edits, dependency graph and limitations: debugger.json.
