# FAR Investigation: semantic-causal-distorted

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-27T12:00:00Z`
- Input SHA-256: `e005783eea101beb1eac57d0d3ff14e38cb4f4786c7db3240f09dd48d82b6bc0`
- Report SHA-256: `e573a339dc4521ff2842bf156ca62966a9fc6c73889fb4d6377270455996a582`
- Source snapshots: 1; claim candidates: 2; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### c1

Source: `primary`; exact span: `0:32`

Source quotation:

```text
Rain is correlated with traffic.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### c2

Source: `primary`; exact span: `33:53`

Source quotation:

```text
Rain causes traffic.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: c1; conclusion: c2
- Formal result: **ENTAILS_CONDITIONALLY**
- Natural-language fidelity: **unverified**
- Unestablished premises: c1

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=e567d5b738d7475f9bf42763560772b2ff68465b5c7d7c388bd74b03be56fa14; authenticity=unverified

## Argument-scheme critical questions (unadjudicated)

These are hypothesis/checklist triggers, NOT findings that an argument is invalid.

- c2 / CAUSAL\_IDENTIFICATION: Does independent causal-identification evidence address confounding, directionality and alternatives? Temporal sequence/correlation alone is insufficient.

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation

## Epistemic debugger

Controlled-language checks; external truth and general semantic fidelity remain unverified.

- c1: CONTRADICTED
- c2: SUPPORTED_IN_GRAMMAR
- reading: NOT_ACCEPTED; SEMANTIC_MISMATCH; counterfactual EXACT_MINIMUM_WITHIN_CONTRACT.

Full exact source references, lost-distinction witnesses, assumption edits, dependency graph and limitations: debugger.json.
