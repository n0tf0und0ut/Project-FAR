# FAR Investigation: affirming-consequent

> Research/prototype output; not certified factual truth. Semantic mappings are not independently verified.

## Scope and input

- As-of/capture time: `2026-10-26T12:00:00Z`
- Input SHA-256: `cd5be0e20942057855b4473d1e9c5670f151de1e2ea68d440b52a67d71ae03ea`
- Report SHA-256: `4bc8851f9a4b8863aa935b11e4947f1741ac365dbbe4a952d3235cfd66deaf40`
- Source snapshots: 1; claim candidates: 3; candidate readings: 1
- Retrieval completeness and external source authenticity: **not established**

## Attributed claims

### p1

Source: `primary`; exact span: `0:39`

Source quotation:

```text
If the lamp is on then the room is lit.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### p2

Source: `primary`; exact span: `40:56`

Source quotation:

```text
The room is lit.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


### p3

Source: `primary`; exact span: `57:72`

Source quotation:

```text
The lamp is on.
```

- Evidential/conditional status: **NOT_ESTABLISHED**
- Numerical status: **NOT_ESTABLISHED**
- Semantic mapping: **unreviewed** (not independent validation)
- Evidence relations tested: 0


## Proposed arguments and formal countermodels

### reading

- Premises: p1, p2; conclusion: p3
- Formal result: **DOES_NOT_ENTAIL**
- Natural-language fidelity: **unverified**
- Interpretation: Developer supplied; semantic fidelity is not established by the tool.
- Formal countermodel: `{"P": false, "Q": true}`
- Unestablished premises: p1, p2

## Acquisition history

- primary: primary; method=text\_provided\_v1; raw SHA-256=54d924a4138d11b51c05c473c3f588f15b2e2341ca8d614ea5de23915808c328; authenticity=unverified

## Unknowns and blockers

- Claims, citations and argument readings are machine-proposed or user-supplied and have no independently verified semantic mapping.
- Search recall, source independence and world-truth status are not established.

## Assurance boundaries

- formal entailment: exhaustive bounded propositional valuations
- source integrity: byte-level SHA-256 of supplied snapshot, not authenticity
- quote validation: exact span equality, not semantic entailment
- semantic fidelity: unverified: claim and evidence text to atoms/formulas is supplied by author
- evidence independence: origin_ids are reported, not independently authenticated
- real world truth: not established
- open world search completeness: not established
- structured numbers: deterministic computations over supplied JSON, not verification of measurement, population, scope, or claim interpretation

## Epistemic debugger

Controlled-language checks; external truth and general semantic fidelity remain unverified.

- p1: CONTRADICTED
- p2: CONTRADICTED
- p3: CONTRADICTED
- reading: NOT_ACCEPTED; SEMANTIC_MISMATCH; counterfactual NO_REPAIR_WITHIN_CONTRACT.

Full exact source references, lost-distinction witnesses, assumption edits, dependency graph and limitations: debugger.json.
