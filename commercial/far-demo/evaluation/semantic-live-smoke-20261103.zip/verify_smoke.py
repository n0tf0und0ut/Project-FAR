"""Deterministic recorded-byte/sequence validation; never model generation or attestation."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for name, expected in manifest.items():
        assert sha((ROOT / name).read_bytes()) == expected, name
    freeze_raw = (ROOT / 'freeze.json').read_bytes()
    assert sha(freeze_raw) == (ROOT / 'freeze.sha256').read_text().strip()
    freeze = json.loads(freeze_raw)
    assert sha((ROOT / 'run_smoke.py').read_bytes()) == freeze['wrapper_sha256']
    for name, expected in freeze['source_sha256'].items():
        assert sha((ROOT / 'sources' / name).read_bytes()) == expected
    rows = [json.loads(line) for line in (ROOT / 'events.jsonl').read_text().splitlines()]
    types = [r['event'] for r in rows]
    assert types.count('freeze_written_before_generation') == 1
    assert types.count('generation_started') == 1
    assert types.count('provider_request_received') == 1
    assert types.index('freeze_written_before_generation') < types.index('generation_started')
    assert all(rows[i]['monotonic'] <= rows[i + 1]['monotonic'] for i in range(len(rows) - 1))
    expected = json.loads((ROOT / 'expected-provider-request.json').read_text())
    actual = json.loads((ROOT / 'actual-provider-request.raw.json').read_text())
    assert expected == actual and actual['max_tokens'] == 4096
    canonical = lambda value: json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
    assert sha(canonical(expected)) == freeze['provider_request_sha256']
    assert sha(canonical(json.loads((ROOT / 'input.json').read_text()))) == freeze['input_sha256']
    inputs = json.loads((ROOT / 'input-token-ids.json').read_text())
    assert sha(canonical(inputs)) == freeze['tokenizer_input_ids_sha256']
    assert len(inputs[0]) == freeze['input_tokens']
    files = json.loads((ROOT / 'model-files.json').read_text())
    assert sha(canonical(files)) == freeze['model_file_inventory_sha256']
    for name, identity in files.items():
        if name != 'model.safetensors':
            assert sha((ROOT / 'model-nonweight-assets' / name).read_bytes()) == identity['sha256']
    response = json.loads((ROOT / 'provider-response.json').read_text())
    raw = (ROOT / 'raw-model-output.txt').read_text()
    assert response['choices'][0]['message']['content'] == raw
    tokens = json.loads((ROOT / 'completion-token-ids.json').read_text())
    recorded = [token for row in rows if row['event'] == 'generated_token_ids' for token in row['token_ids']]
    assert tokens == recorded
    assert len(tokens) == response['usage']['completion_tokens'] == 218
    assert response['usage']['prompt_tokens'] == 525
    telemetry = json.loads((ROOT / 'provider-telemetry.json').read_text())
    assert telemetry['output_sha256'] == sha(raw.encode())
    assert 0 < telemetry['generation_seconds'] < 30
    outcome = json.loads((ROOT / 'route-outcome.json').read_text())
    assert outcome['http_status'] == 502
    assert outcome['provider_request_count_at_route_return'] == 1
    assert 'failed source-bound' in outcome['body']['detail']
    try:
        json.loads(raw)
    except json.JSONDecodeError:
        pass
    else:
        raise AssertionError('Original raw output unexpectedly parsed as strict JSON')
    completion = json.loads((ROOT / 'completion-record.json').read_text())
    assert completion['source_bytes_unchanged'] and completion['one_call_only']
    assert completion['provider_request_count'] == 1
    assert freeze['inference']['semantic_client_timeout_seconds'] == 30
    assert freeze['inference']['max_new_tokens'] == 4096
    print(json.dumps({'status': 'RECORDED_BYTES_AND_ONE_CALL_SEQUENCE_VALID',
                      'route_result': 'FAILED_OUTPUT_CONFORMANCE_HTTP_502',
                      'provider_access': 'ONE_ACTUAL_LOCAL_MODEL_COMPLETION_RECORDED',
                      'cryptographic_execution_attestation': False,
                      'semantic_efficacy_established': False}, sort_keys=True))


if __name__ == '__main__':
    main()
