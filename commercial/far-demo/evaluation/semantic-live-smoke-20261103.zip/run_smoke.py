"""One prospectively frozen engineering access/conformance call; no efficacy claim."""
from __future__ import annotations

import asyncio
import hashlib
import http.server
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import threading
import time
import traceback
from datetime import datetime, timezone

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from fastapi import FastAPI
from fastapi.testclient import TestClient
from far_demo import augmentation, semantic

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/e1c41a89d76e/worktrees/616')
MODEL = 'Qwen/Qwen2.5-0.5B-Instruct'
REVISION = '7ae557604adf67be50417f59c2c2f167def9a775'
PORT = 18616
URL = f'http://127.0.0.1:{PORT}/v1/chat/completions'
PUBLIC_LOCAL_TEST_TOKEN = 'public-local-engineering-smoke-616'


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def write_once(name, raw):
    p = ROOT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())


def document(name, value):
    write_once(name, canonical(value) + b'\n')


def event(kind, **fields):
    row = {'event': kind, 'at': timestamp(), 'monotonic': time.monotonic(), **fields}
    with (ROOT / 'events.jsonl').open('ab') as f:
        f.write(canonical(row) + b'\n')
        f.flush()


def main():
    if (ROOT / 'freeze.json').exists() or (ROOT / 'route-outcome.json').exists():
        raise FileExistsError('An existing freeze/outcome cannot be overwritten or favorably retried')
    torch.set_num_threads(4)
    torch.manual_seed(61601)
    torch.use_deterministic_algorithms(True)
    event('preparation_started')
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, trust_remote_code=False)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, revision=REVISION, trust_remote_code=False,
        torch_dtype=torch.bfloat16, attn_implementation='sdpa').cpu().eval()
    model_state = hashlib.sha256()
    parameter_count = sum(t.numel() for t in model.parameters())
    for name, tensor in sorted(model.state_dict().items()):
        model_state.update(canonical({'name': name, 'shape': list(tensor.shape), 'dtype': str(tensor.dtype)}))
        model_state.update(tensor.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
    snapshot = Path(os.path.expanduser('~/.cache/huggingface/hub/models--Qwen--Qwen2.5-0.5B-Instruct/snapshots')) / REVISION
    model_files = {}
    for p in sorted(snapshot.iterdir()):
        if p.is_file():
            h = hashlib.sha256()
            with p.open('rb') as f:
                for block in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(block)
            model_files[p.name] = {'bytes': p.stat().st_size, 'sha256': h.hexdigest()}
    source_names = [
        'commercial/far-demo/src/far_demo/semantic.py',
        'commercial/far-demo/src/far_demo/augmentation.py',
        'commercial/far-demo/src/far_demo/__init__.py',
    ]
    sources = {name: sha((REPO / name).read_bytes()) for name in source_names}
    source_identity = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=REPO, text=True).splitlines()
    raw_input = {
        'claim': 'Every failure produces an alert.',
        'reasoning': 'Every alerted call failed, so every failure produces an alert.',
        'confidence': 95,
        'supporting_evidence': [
            {'statement': 'Every alerted call failed.',
             'source': 'Authored logical premise for an engineering smoke fixture; not observed real calls.'}],
        'challenging_evidence': [], 'assumptions': [], 'alternatives': [], 'falsifier': '',
    }
    app = FastAPI()
    app.include_router(augmentation.router)
    app.include_router(semantic.router)
    client = TestClient(app)
    start = client.post('/api/augment/start', json=raw_input)
    if start.status_code != 200:
        raise RuntimeError('Existing session creation failed before any model generation')
    session = start.json()
    refs = semantic._refs(session)
    expected_request = {
        'model': MODEL,
        'messages': [
            {'role': 'system', 'content': semantic.SYSTEM_PROMPT},
            {'role': 'user', 'content': json.dumps({'source_strings': refs}, ensure_ascii=False, sort_keys=True)}],
        'max_tokens': 4096,
        'response_format': {'type': 'json_object'},
    }
    tokenized = tokenizer.apply_chat_template(
        expected_request['messages'], tokenize=True, add_generation_prompt=True, return_tensors='pt')
    source_copy = ROOT / 'sources'
    for name in source_names:
        write_once('sources/' + name, (REPO / name).read_bytes())
    document('input.json', raw_input)
    document('session.json', session)
    document('expected-provider-request.json', expected_request)
    document('input-token-ids.json', tokenized.tolist())
    document('model-files.json', model_files)
    freeze = {
        'schema': 'far-semantic-live-engineering-smoke/0.1',
        'purpose': 'One live access and conformance check only; not semantic efficacy, human benefit, independence, reliability, or commercial validation',
        'registered_at': timestamp(), 'repository_commit': source_identity[0], 'repository_tree': source_identity[1],
        'source_sha256': sources, 'wrapper_sha256': sha(Path(__file__).read_bytes()),
        'input_sha256': sha(canonical(raw_input)), 'session_sha256': session['sha256'],
        'provider_request_sha256': sha(canonical(expected_request)),
        'model': MODEL, 'revision': REVISION, 'loaded_state_sha256': model_state.hexdigest(),
        'parameter_count': parameter_count, 'model_file_inventory_sha256': sha(canonical(model_files)),
        'tokenizer_input_ids_sha256': sha(canonical(tokenized.tolist())), 'input_tokens': int(tokenized.shape[-1]),
        'runtime': {'python': platform.python_version(), 'torch': torch.__version__,
                    'transformers': importlib.metadata.version('transformers'),
                    'tokenizers': importlib.metadata.version('tokenizers'),
                    'safetensors': importlib.metadata.version('safetensors'),
                    'fastapi': importlib.metadata.version('fastapi'), 'httpx': importlib.metadata.version('httpx')},
        'inference': {'device': 'cpu', 'dtype': 'bfloat16', 'attention': 'sdpa', 'threads': 4,
                      'deterministic_algorithms': True, 'seed': 61601, 'do_sample': False,
                      'max_new_tokens': 4096, 'provider_host_max_time_seconds': 120,
                      'semantic_client_timeout_seconds': 30, 'response_size_limit_bytes': 65536},
        'transport': {'url': URL, 'loopback_only': True, 'production': False,
                      'json_format_support': 'Prompt only; no grammar enforcement or output rewriting',
                      'auth': 'Public static scratch-only access token; no external provider credentials'},
        'conditions': {'max_model_calls': 1, 'outcome_based_retry': False, 'scripted_output': False,
                       'validators_modified': False, 'timeout_modified': False,
                       'failure_preservation': True},
        'criteria': ['Record actual provider/model generation, HTTP outcome and unchanged validator disposition',
                     'A valid report is only access/conformance evidence; no diagnosis quality score is inferred',
                     'Malformed output, timeout or rejection is retained as the one result; no favorable retry'],
        'billing': {'external_api_charges_usd': 0, 'local_compute_cost_usd': None, 'energy_joules': None},
    }
    document('freeze.json', freeze)
    write_once('freeze.sha256', (sha((ROOT / 'freeze.json').read_bytes()) + '\n').encode())
    event('freeze_written_before_generation', freeze_sha256=sha((ROOT / 'freeze.json').read_bytes()))
    print('FREEZE', sha((ROOT / 'freeze.json').read_bytes()), flush=True)
    generated_done = threading.Event()
    request_count = [0]

    class Recorder:
        def __init__(self):
            self.first = True
            self.tokens = []

        def put(self, value):
            ids = value.detach().cpu().reshape(-1).tolist()
            if self.first:
                self.first = False
                return
            self.tokens.extend(ids)
            event('generated_token_ids', token_ids=ids, completion_tokens=len(self.tokens))

        def end(self):
            pass

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            request_count[0] += 1
            if request_count[0] > 1:
                self.send_error(409, 'Only one prospectively frozen call is permitted')
                return
            raw = self.rfile.read(int(self.headers['Content-Length']))
            write_once('actual-provider-request.raw.json', raw)
            request = json.loads(raw)
            if request != expected_request:
                document('provider-error.json', {'error': 'Request differs from frozen request', 'at': timestamp()})
                self.send_error(422, 'Request differs from frozen request')
                generated_done.set()
                return
            event('provider_request_received', request_sha256=sha(raw))
            recorder = Recorder()
            started = time.monotonic()
            try:
                ids = tokenizer.apply_chat_template(request['messages'], tokenize=True,
                    add_generation_prompt=True, return_tensors='pt')
                event('generation_started', input_tokens=int(ids.shape[-1]))
                with torch.inference_mode():
                    output = model.generate(
                        ids, attention_mask=torch.ones_like(ids), max_new_tokens=request['max_tokens'],
                        do_sample=False, max_time=120, streamer=recorder,
                        pad_token_id=tokenizer.eos_token_id)
                completion = output[0, ids.shape[-1]:].detach().cpu().tolist()
                text = tokenizer.decode(completion, skip_special_tokens=True)
                write_once('raw-model-output.txt', text.encode())
                document('completion-token-ids.json', completion)
                elapsed = time.monotonic() - started
                eos_ids = model.generation_config.eos_token_id
                eos_ids = eos_ids if isinstance(eos_ids, list) else [eos_ids]
                reason = 'stop' if completion and completion[-1] in eos_ids else ('length' if len(completion) == request['max_tokens'] else 'host_time_limit')
                response = {'id': 'scratch-semantic-smoke-616', 'object': 'chat.completion',
                    'model': MODEL, 'choices': [{'index': 0, 'message': {'role': 'assistant', 'content': text}, 'finish_reason': reason}],
                    'usage': {'prompt_tokens': int(ids.shape[-1]), 'completion_tokens': len(completion), 'total_tokens': int(output.shape[-1])}}
                document('provider-response.json', response)
                document('provider-telemetry.json', {'generation_seconds': elapsed, 'finish_reason': reason,
                    'prompt_tokens': int(ids.shape[-1]), 'completion_tokens': len(completion),
                    'tokens_observed_by_streamer': len(recorder.tokens), 'output_sha256': sha(text.encode()),
                    'output_bytes': len(text.encode()), 'external_api_charges_usd': 0,
                    'local_compute_cost_usd': None, 'energy_joules': None})
                event('generation_completed', seconds=elapsed, completion_tokens=len(completion), output_sha256=sha(text.encode()))
                payload = canonical(response)
                try:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                    event('provider_http_200_delivered', bytes=len(payload))
                except (BrokenPipeError, ConnectionResetError):
                    event('provider_delivery_failed_after_client_disconnect')
            except Exception as error:
                document('provider-error.json', {'type': type(error).__name__, 'message': str(error),
                    'traceback': traceback.format_exc(), 'elapsed_seconds': time.monotonic() - started,
                    'generated_token_ids': recorder.tokens, 'partial_text': tokenizer.decode(recorder.tokens, skip_special_tokens=True)})
                self.send_error(500, 'Actual model generation failed')
            finally:
                generated_done.set()

    server = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    os.environ['FAR_SEMANTIC_URL'] = URL
    os.environ['FAR_SEMANTIC_MODEL'] = MODEL
    os.environ['FAR_SEMANTIC_ACCESS_TOKEN'] = PUBLIC_LOCAL_TEST_TOKEN
    os.environ['FAR_SEMANTIC_API_KEY'] = ''
    os.environ['FAR_SEMANTIC_OUTPUT_TOKEN_FIELD'] = 'max_tokens'
    route_start = time.monotonic()
    event('single_route_call_started')
    response = client.post('/api/augment/semantic', json={'session': session},
                           headers={'X-FAR-Augment-Token': PUBLIC_LOCAL_TEST_TOKEN})
    elapsed = time.monotonic() - route_start
    document('route-outcome.json', {'http_status': response.status_code, 'elapsed_seconds': elapsed,
        'body': response.json(), 'provider_request_count_at_route_return': request_count[0],
        'assurance': 'Engineering access/conformance only; not efficacy or human/commercial benefit'})
    event('single_route_call_completed', http_status=response.status_code, seconds=elapsed)
    print('ROUTE', response.status_code, round(elapsed, 4), flush=True)
    # Preserve the model's actual completion even if the unchanged client times out.
    deadline = time.monotonic() + 150
    while not generated_done.wait(timeout=1):
        if time.monotonic() > deadline:
            document('generation-still-running.json', {'at': timestamp(), 'note': 'Host wait exhausted; retain token journal'})
            break
    server.shutdown()
    server.server_close()
    if (ROOT / 'raw-model-output.txt').exists():
        raw_text = (ROOT / 'raw-model-output.txt').read_text()
        try:
            report = semantic._create_report(session, semantic._config(), raw_text)
            posthoc = {'valid': True, 'verification': semantic.verify_report(report, session), 'report': report}
        except Exception as error:
            posthoc = {'valid': False, 'error_type': type(error).__name__, 'error': str(error)}
        document('raw-output-posthoc-unchanged-validator.json', posthoc)
    final_sources = {name: sha((REPO / name).read_bytes()) for name in source_names}
    document('completion-record.json', {'finished_at': timestamp(), 'provider_request_count': request_count[0],
        'source_bytes_unchanged': final_sources == sources, 'frozen_source_sha256': sources,
        'final_source_sha256': final_sources, 'one_call_only': request_count[0] == 1,
        'no_outcome_based_retry': True, 'no_repository_mutations': True})
    event('smoke_finished')


if __name__ == '__main__':
    main()
